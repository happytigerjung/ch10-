package ch10;

import java.util.Scanner;

public class StackApp {

	public static void main(String[] args) {
		StringStack sts = new StringStack();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("저장 공간의 총 숫자 입력");
		int num = sc.nextInt();
		
		sts.length();
		

	}

}

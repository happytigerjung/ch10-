package ch10;

public class StringStack implements Stack {

	@Override
	public int length() {
	
		return 0;
	}

	@Override
	public int capacity() {
		
		return 0;
	}

	@Override
	public String pop() {
		
		return null;
	}

	@Override
	public boolean push(String val) {
		
		return false;
	}

}
